#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Инструмент мастерской AI КОМАНДА: проверка среды и создание новой команды.

Команды: proverka, novaya, spisok, sync, obnovit.
"""
import argparse
import datetime
import json
import re
import shutil
import sys
import tempfile
import os
from pathlib import Path

ZDES = Path(__file__).resolve().parent
sys.path.insert(0, str(ZDES))
import komanda as K  # noqa: E402

MAST = ZDES.parent            # _masterskaya
KOREN = MAST.parent           # корень мастерской
KOMANDY = KOREN / "komandy"
DIAG = KOREN / "diagnostika"
DIAG_FAYL = DIAG / "diagnostika.json"
DIAG_FAYLY = ("dosye.md", "kartochka.md", "tablica.md")
SHABLON = MAST / "shablony" / "komanda"
TRANSLIT = dict(zip("абвгдеёжзийклмнопрстуфхцчшщъыьэюя",
                    ["a", "b", "v", "g", "d", "e", "e", "zh", "z", "i", "y", "k", "l", "m", "n", "o", "p", "r", "s",
                     "t", "u", "f", "h", "c", "ch", "sh", "sch", "", "y", "", "e", "yu", "ya"]))


def sdelat_id(nazvanie):
    s = "".join(TRANSLIT.get(ch, ch) for ch in nazvanie.lower())
    s = re.sub(r"[^a-z0-9]+", "-", s).strip("-")
    return s[:40].strip("-") or "komanda"


def postavit_instrument(papka):
    (papka / "skripty").mkdir(parents=True, exist_ok=True)
    for imya in ("komanda.py", "karta.template.html"):
        shutil.copy2(ZDES / imya, papka / "skripty" / imya)


def cmd_proverka(a):
    ok = True

    def stroka(horosho, tekst):
        nonlocal ok
        ok = ok and horosho
        print(("OK   " if horosho else "ПЛОХО ") + tekst)

    stroka(sys.version_info >= (3, 8), "Python %s (нужен 3.8 или новее)" % sys.version.split()[0])
    stroka(SHABLON.is_dir() and (ZDES / "karta.template.html").exists(), "Шаблоны мастерской на месте")
    try:
        KOMANDY.mkdir(exist_ok=True)
        proba = KOMANDY / ".proba-zapisi"
        proba.write_text("ok", encoding="utf-8")
        proba.unlink()
        stroka(True, "В папку komandy/ можно писать")
    except OSError as e:
        stroka(False, "Нет права записи в папку komandy/.")
        print("Открой папку в режиме с правом записи или разреши агенту запись в эту папку, затем повтори proverka.")
    try:
        with tempfile.TemporaryDirectory() as tmp:
            p = sozdat(Path(tmp) / "proba", "Проба", "proba")
            stroka((p / "karta.html").stat().st_size > 1000, "Пробная команда и карта собираются")
    except Exception as e:  # проверка должна сказать причину, а не упасть
        stroka(False, "Пробная команда не собралась: %s" % e)
        if isinstance(e, PermissionError):
            print("Открой папку в режиме с правом записи или разреши агенту запись в эту папку, затем повтори proverka.")
    n = len([p for p in (MAST / "navyki").iterdir() if p.is_dir() and (p / "SKILL.md").is_file()]) if (MAST / "navyki").is_dir() else 0
    stroka(n > 0, "Навык проводника на месте (%d); скрытые копии обновляет отдельная команда sync" % n)
    gotovye = cmd_spisok(a, tiho=True)
    print("Команд в мастерской: %d%s" % (len(gotovye), (" (" + ", ".join(gotovye) + ")") if gotovye else ""))
    print("ИТОГ: " + ("мастерская готова к работе." if ok else "есть проблемы, сначала исправь их."))
    if not ok:
        sys.exit(1)


def sozdat(papka, nazvanie, kid):
    shutil.copytree(SHABLON, papka)
    for imya in K.PAPKI:
        (papka / imya).mkdir(exist_ok=True)
    postavit_instrument(papka)
    team = {
        "schema": 2,
        "provodnik_versiya": K.VERSIYA,
        "komanda": {"id": kid, "nazvanie": nazvanie, "sozdana": datetime.date.today().isoformat()},
        "process": {"nazvanie": "", "vhod": "", "rezultat": "", "pochemu": "", "kriterii": [], "granica": "", "prinimaet": ""},
        "shag": 0,
        "sleduyushchee": "Расспросить о последнем реальном деле.",
        "zhdem_ot_vas": "Последнее реальное дело и как оно шло.",
        "da": {"process": None, "shema": None, "versiya": None, "zapusk": None},
        "roli": [], "navyki": [], "styki": [], "instrumenty": [], "kontrolnye_tochki": [],
        "priemka": {"status": "ne-provedena", "usloviya": "", "delo": "", "kogda": ""},
        "zapusk": {"sposob": "", "raspisanie": ""},
    }
    (papka / "team.json").write_text(json.dumps(team, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (papka / "zhurnal.md").write_text(K.ZAGOLOVOK, encoding="utf-8")
    for f in papka.glob("*.md"):
        f.write_text(f.read_text(encoding="utf-8").replace("{{NAZVANIE}}", nazvanie).replace("{{ID}}", kid),
                     encoding="utf-8")
    _, neud = K.sdelat_sync(papka)
    K.sdelat_kartu(papka)
    if neud:
        print("ВНИМАНИЕ: не удалось записать копии навыков: %s. Позже выполни sync с полным доступом к папке." % "; ".join(neud))
    return papka


def cmd_novaya(a):
    kid = a.id or sdelat_id(a.nazvanie)
    if not K.ID_RE.match(kid):
        sys.exit("id «%s» не годится: только латиница, цифры и дефис." % kid)
    papka = KOMANDY / kid
    if getattr(a, "iz_diagnostiki", False) and not DIAG_FAYL.exists():
        sys.exit("Диагностики нет: команду из неё создать нельзя.")
    if getattr(a, "iz_diagnostiki", False):
        proverit_perenos(chitat_diag(), kid, getattr(a, "kak_est", False))
    if papka.exists():
        if getattr(a, "iz_diagnostiki", False):
            perenesti_diag(papka, kid, getattr(a, "kak_est", False))
            return
        sys.exit("Команда «%s» уже есть: %s. Продолжи её или выбери другое имя." % (kid, papka))
    KOMANDY.mkdir(exist_ok=True)
    tmp = Path(tempfile.mkdtemp(prefix=".%s-" % kid, dir=str(KOMANDY)))
    tmp.rmdir()
    try:
        sozdat(tmp, a.nazvanie, kid)
        os.replace(str(tmp), str(papka))
    except BaseException:
        if tmp.exists():
            shutil.rmtree(tmp)
        raise
    print("Команда создана: komandy/%s" % kid)
    print("Карта: komandy/%s/karta.html" % kid)
    print("Дальше: шаг 0, вход. Команды инструмента запускай так:")
    print("  python3 komandy/%s/skripty/komanda.py status" % kid)
    if getattr(a, "iz_diagnostiki", False):
        perenesti_diag(papka, kid, getattr(a, "kak_est", False))


# ---------- диагностика: выбор процесса до создания команды ----------

OCENKI = ("rutinnost", "pravilo", "proveryaemost", "cena_oshibki")
FLAGI = ("besit", "ne_delayut", "probovali_lyudyam", "klientskaya", "gotov_naznachit")
POROG_IPU = 40


def zapisat_tekst(put, tekst):
    put.parent.mkdir(parents=True, exist_ok=True)
    tmp = put.with_name(put.name + ".tmp")
    tmp.write_text(tekst, encoding="utf-8")
    os.replace(str(tmp), str(put))


def chitat_diag():
    if not DIAG_FAYL.exists():
        return None
    try:
        return json.loads(DIAG_FAYL.read_text(encoding="utf-8"))
    except ValueError as e:
        sys.exit("Файл диагностики повреждён: %s" % e)


def chislo(v):
    return v if isinstance(v, (int, float)) and not isinstance(v, bool) else None


def proverit_diag(d):
    zam = []
    if not isinstance(d, dict) or not isinstance(d.get("processy"), list) or any(not isinstance(p, dict) for p in d.get("processy", [])):
        return ["processy должен быть списком объектов."]
    ids = [p.get("id") for p in d["processy"]]
    if any(not isinstance(x, str) or not x for x in ids) or len(set(x for x in ids if isinstance(x, str))) != len(ids):
        zam.append("id процессов должны быть непустыми и уникальными.")
    for p in d["processy"]:
        for key in ("raz_v_ned", "min_na_raz"):
            v = p.get(key)
            if v is not None and (chislo(v) is None or not 0 < v < float("inf")):
                zam.append("%s: %s должно быть больше нуля." % (p.get("id"), key))
        for key in ("ocenki", "flagi"):
            if p.get(key) is not None and not isinstance(p[key], dict):
                zam.append("%s: %s должен быть объектом." % (p.get("id"), key))
    vybor = d.get("vybor", {})
    if not isinstance(vybor, dict):
        zam.append("vybor должен быть объектом.")
    else:
        for key in ("osnovnoy", "zapasnoy"):
            if vybor.get(key) and vybor[key] not in ids:
                zam.append("vybor.%s ссылается на отсутствующий процесс." % key)
    return zam


def poschitat_diag(d):
    """Считает часы, стоп по частоте, ИПУ и места. Возвращает список замечаний."""
    zam = proverit_diag(d)
    if zam:
        return zam
    for p in d.get("processy", []):
        imya = p.get("nazvanie") or p.get("id") or "?"
        p["chasov"] = p["skorr"] = p["ipu"] = p["mesto"] = None
        p["stop_avto"] = ""
        raz, mn = chislo(p.get("raz_v_ned")), chislo(p.get("min_na_raz"))
        skorr = None
        if raz is not None and mn is not None:
            chasov = raz * mn / 60.0
            skorr = chasov / 1.5
            p["chasov"], p["skorr"] = round(chasov, 1), round(skorr, 1)
            if raz < 2 and chasov < 2:
                p["stop_avto"] = "реже двух раз в неделю и меньше двух часов в неделю"
        oc = p.get("ocenki") or {}
        if not oc:
            continue
        if skorr is None:
            zam.append("«%s»: есть оценки, но нет замера (раз в неделю, минут на раз)." % imya)
            continue
        plohie = [k for k in OCENKI if not (isinstance(oc.get(k), int) and not isinstance(oc.get(k), bool) and 1 <= oc[k] <= 5)]
        if plohie:
            zam.append("«%s»: оценки должны быть целыми от 1 до 5, не хватает: %s." % (imya, ", ".join(plohie)))
            continue
        fl = p.get("flagi") or {}
        net = [k for k in FLAGI if fl.get(k) not in (0, 1, True, False)]
        if net:
            zam.append("«%s»: не заданы признаки (0 или 1): %s." % (imya, ", ".join(net)))
            continue
        f = dict((k, int(fl[k])) for k in FLAGI)
        impact = min(40.0, skorr * 4)
        feas = (oc["rutinnost"] * 4 + oc["pravilo"] * 3 + oc["proveryaemost"] * 4 + (6 - oc["cena_oshibki"]) * 3) * 40.0 / 70.0
        motiv = min(20.0, f["besit"] * 10 + f["ne_delayut"] * 12 + f["probovali_lyudyam"] * 5 + (1 - f["klientskaya"]) * 8)
        shtraf = (1 - f["gotov_naznachit"]) * 15 + f["klientskaya"] * 20
        p["ipu"] = int(round(max(0.0, min(100.0, impact + feas + motiv - shtraf))))
    zhivye = [p for p in d.get("processy", []) if not otsechen(p)]
    zhivye.sort(key=lambda p: (p["ipu"] is None, -(p["ipu"] or 0), -(p["skorr"] or 0)))
    for n, p in enumerate(zhivye, 1):
        p["mesto"] = n
    return zam


def otsechen(p):
    if p.get("ostavlen_chelovekom"):
        return ""
    return p.get("stop") or p.get("stop_avto") or ""


def tablica_diag(d):
    def ya(v):
        return "" if v is None else str(v).replace("|", "/").replace("\n", " ")
    shapka = ["Место", "Процесс", "Кто делает", "Раз/нед", "Мин/раз", "Часов/нед", "Скорр. часы",
              "Критерий готовности", "Рут.", "Прав.", "Пров.", "Ошибка", "ИПУ"]
    stroki = ["# Таблица процессов", "", "Составлено проводником по вашим ответам, проверьте.", "",
              "| " + " | ".join(shapka) + " |", "|" + "---|" * len(shapka)]
    vse = d.get("processy", [])
    for p in sorted([x for x in vse if x.get("mesto")], key=lambda x: x["mesto"]):
        oc = p.get("ocenki") or {}
        ipu = ya(p.get("ipu"))
        if p.get("ipu") is not None and p["ipu"] < POROG_IPU:
            ipu += " (ниже порога, лучше не первым)"
        stroki.append("| " + " | ".join([ya(p["mesto"]), ya(p.get("formula") or p.get("nazvanie")), ya(p.get("kto")),
                                         ya(p.get("raz_v_ned")), ya(p.get("min_na_raz")), ya(p.get("chasov")), ya(p.get("skorr")),
                                         ya(p.get("kriteriy"))] + [ya(oc.get(k)) for k in OCENKI] + [ipu]) + " |")
    ubrano = [p for p in vse if otsechen(p)]
    if ubrano:
        stroki += ["", "## Отложили", "", "| Процесс | Почему |", "|---|---|"]
        stroki += ["| %s | %s |" % (ya(p.get("formula") or p.get("nazvanie")), ya(otsechen(p))) for p in ubrano]
    return "\n".join(stroki) + "\n"


def cmd_diagnostika(a):
    d = chitat_diag()
    if a.chto == "nachat":
        kid = getattr(a, "komanda", None) or ""
        if kid and (not K.ID_RE.fullmatch(kid) or not (KOMANDY / kid / "team.json").is_file()):
            sys.exit("Укажи id уже созданной команды в --komanda.")
        if d and d.get("status") not in ("zavershena", "otmenena"):
            print("Диагностика уже начата, продолжай её: %d процессов записано." % len(d.get("processy", [])))
            return
        if d:
            arh = DIAG / ("arhiv-%s" % datetime.date.today().isoformat())
            n = 1
            while arh.exists():
                n += 1
                arh = DIAG / ("arhiv-%s-%d" % (datetime.date.today().isoformat(), n))
            arh.mkdir()
            for f in list(DIAG.iterdir()):
                if f.is_file():
                    shutil.move(str(f), str(arh / f.name))
        d = {"schema": 1, "status": "idet", "nachata": datetime.date.today().isoformat(), "shag_diagnostiki": 1,
             "o_biznese": "", "zhdem_ot_vas": "", "processy": [],
             "vybor": {"osnovnoy": "", "zapasnoy": "", "shagov_v_processe": None, "pochemu": ""}, "komanda": kid}
        zapisat_tekst(DIAG_FAYL, json.dumps(d, ensure_ascii=False, indent=2) + "\n")
        print("Диагностика начата: diagnostika/diagnostika.json")
        return
    if not d:
        sys.exit("Диагностика не начата. Выполни: diagnostika nachat")
    if a.chto == "otmenit":
        d["status"] = "otmenena"
        zapisat_tekst(DIAG_FAYL, json.dumps(d, ensure_ascii=False, indent=2) + "\n")
        arh = arhiv_diag()
        print("Диагностика отменена: %s" % arh.relative_to(KOREN))
        return
    if a.chto == "perenesti":
        if not a.id or not K.ID_RE.fullmatch(a.id):
            sys.exit("Укажи id команды: diagnostika perenesti <id>")
        papka = KOMANDY / a.id
        if KOMANDY.resolve() not in papka.resolve().parents or not (papka / "team.json").exists():
            sys.exit("Команды «%s» нет." % a.id)
        perenesti_diag(papka, a.id, a.kak_est)
        return
    errors = proverit_diag(d)
    if errors:
        for z in errors:
            print("ЗАМЕЧАНИЕ: " + z)
        return
    zam = poschitat_diag(d)
    if a.chto == "reyting":
        shutil.copyfile(str(DIAG_FAYL), str(DIAG_FAYL.with_name("diagnostika.json.bak")))
        zapisat_tekst(DIAG_FAYL, json.dumps(d, ensure_ascii=False, indent=2) + "\n")
        zapisat_tekst(DIAG / "tablica.md", tablica_diag(d))
    vse = d.get("processy", [])
    print("Диагностика: %s, шаг %s из 12, процессов %d, отложено %d" % (
        {"idet": "идёт", "zavershena": "завершена"}.get(d.get("status"), d.get("status")),
        d.get("shag_diagnostiki", "?"), len(vse), len([p for p in vse if otsechen(p)])))
    if d.get("zhdem_ot_vas"):
        print("Ждём от человека: %s" % d["zhdem_ot_vas"])
    for p in sorted([x for x in vse if x.get("mesto")], key=lambda x: x["mesto"]):
        print("%d. %s | часов в неделю после поправки: %s | ИПУ: %s%s" % (
            p["mesto"], p.get("nazvanie") or p.get("id"), "нет замера" if p["skorr"] is None else p["skorr"],
            "не оценён" if p["ipu"] is None else p["ipu"],
            " (ниже порога %d)" % POROG_IPU if p["ipu"] is not None and p["ipu"] < POROG_IPU else ""))
    for p in vse:
        if otsechen(p):
            print("отложен: %s | %s" % (p.get("nazvanie") or p.get("id"), otsechen(p)))
    osn = [p for p in vse if p.get("id") and p.get("id") == (d.get("vybor") or {}).get("osnovnoy")]
    if osn and osn[0].get("skorr") is not None:
        p = osn[0]
        print("Выбран: %s | часов в неделю: %s | раз в неделю: %s | команда снимет примерно: %s ч" % (
            p.get("nazvanie"), p["skorr"], p.get("raz_v_ned"), round(p["skorr"] * 0.35, 1)))
    for z in zam:
        print("ЗАМЕЧАНИЕ: " + z)
    if a.chto == "reyting":
        print("Таблица записана: diagnostika/tablica.md")


def arhiv_diag():
    arh = DIAG / ("arhiv-%s" % datetime.date.today().isoformat())
    n = 1
    while arh.exists():
        n += 1
        arh = DIAG / ("arhiv-%s-%d" % (datetime.date.today().isoformat(), n))
    arh.mkdir()
    for f in list(DIAG.iterdir()):
        if f.is_file():
            shutil.move(str(f), str(arh / f.name))
    return arh


def proverit_perenos(d, kid, kak_est=False):
    if not d:
        sys.exit("Диагностики нет, переносить нечего.")
    errors = proverit_diag(d)
    if errors:
        sys.exit("ЗАМЕЧАНИЕ: " + "; ".join(errors))
    previous = d.get("komanda")
    if previous and previous != kid and (KOMANDY / previous / "team.json").is_file():
        sys.exit("Диагностика уже связана с другой командой: %s." % previous)
    missing = []
    if not d.get("vybor", {}).get("osnovnoy"):
        missing.append("vybor.osnovnoy")
    missing += [name for name in ("dosye.md", "kartochka.md") if not (DIAG / name).is_file()]
    if missing and not kak_est:
        sys.exit("Перенос остановлен, не хватает: %s. Неполный перенос: --kak-est." % ", ".join(missing))


def perenesti_diag(papka, kid, kak_est=False):
    d = chitat_diag()
    if not d:
        sys.exit("Диагностики нет, переносить нечего.")
    proverit_perenos(d, kid, kak_est)
    cel = papka / "kontekst"
    cel.mkdir(exist_ok=True)
    skolko = 0
    for imya in DIAG_FAYLY:
        if (DIAG / imya).is_file():
            shutil.copyfile(str(DIAG / imya), str(cel / ("diagnostika-" + imya)))
            skolko += 1
    team = K.chitat_team(papka)
    process = team.setdefault("process", {})
    selected = next((p for p in d["processy"] if p.get("id") == d.get("vybor", {}).get("osnovnoy")), None)
    if selected:
        poschitat_diag(d)
        if not process.get("nazvanie"):
            process["nazvanie"] = selected.get("nazvanie", "")
        if not process.get("kriterii"):
            process["kriterii"] = [selected["kriteriy"]] if selected.get("kriteriy") else []
        if not process.get("pochemu"):
            backup = next((p for p in d["processy"] if p.get("id") == d.get("vybor", {}).get("zapasnoy")), {})
            process["pochemu"] = "Место: %s; часов после поправки: %s; следующий: %s." % (selected.get("mesto"), selected.get("skorr"), backup.get("nazvanie") or "не выбран")
    zapisat_tekst(papka / "team.json", json.dumps(team, ensure_ascii=False, indent=2) + "\n")
    K.sdelat_kartu(papka)
    d["status"], d["komanda"] = "zavershena", kid
    zapisat_tekst(DIAG_FAYL, json.dumps(d, ensure_ascii=False, indent=2) + "\n")
    print("Из диагностики перенесено файлов в kontekst/: %d" % skolko)


def cmd_spisok(a, tiho=False):
    imena = []
    for p in sorted(KOMANDY.glob("*/team.json")):
        try:
            t = json.loads(p.read_text(encoding="utf-8"))
        except ValueError:
            continue
        imena.append(p.parent.name)
        if not tiho:
            shag = t.get("shag", 0)
            print("%s | %s | шаг %d: %s | дальше: %s" % (
                p.parent.name, t.get("komanda", {}).get("nazvanie"), shag,
                K.SHAGI[shag] if 0 <= shag < len(K.SHAGI) else "?", t.get("sleduyushchee", "")))
    if not tiho and not imena:
        print("Команд пока нет.")
    if not tiho and DIAG_FAYL.exists():
        try:
            d = chitat_diag()
        except SystemExit:
            print("Файл диагностики повреждён, восстанови из diagnostika.json.bak")
            return imena
        if d.get("status") == "otmenena":
            return imena
        if d.get("status") == "zavershena":
            print("Диагностика завершена, команда: %s. Запасной процесс: %s" % (
                d.get("komanda") or "не создана", (d.get("vybor") or {}).get("zapasnoy") or "нет"))
        else:
            print("Диагностика не закончена: шаг %s из 12. Продолжи её по _masterskaya/shagi/diagnostika.md" % d.get("shag_diagnostiki", "?"))
    return imena


def cmd_sync(a):
    n, neud = K.sdelat_sync(KOREN, MAST / "navyki")
    print("Навыки проводника разложены по трём средам (%d)." % n if not neud else "Не удалось записать: " + "; ".join(neud))
    if neud:
        sys.exit(1)


def cmd_obnovit(a):
    if not K.ID_RE.fullmatch(a.id):
        sys.exit("Обновить можно только id команды.")
    papka = KOMANDY / a.id
    if KOMANDY.resolve() not in papka.resolve().parents:
        sys.exit("Путь команды ведёт за пределы komandy/.")
    if not (papka / "team.json").exists():
        sys.exit("Команды «%s» нет." % a.id)
    postavit_instrument(papka)
    K.sdelat_kartu(papka)
    print("Инструмент и шаблон карты в komandy/%s обновлены до версии %s." % (a.id, K.VERSIYA))


def cmd_vypusk(a):
    """Собирает чистый архив мастерской для раздачи людям (без команд, истории и служебных хвостов)."""
    import re
    import zipfile
    n, neud = K.sdelat_sync(KOREN, MAST / "navyki")
    if neud:
        sys.exit("Не удалось обновить копии навыка проводника: %s." % "; ".join(neud))
    arhiv = KOREN.parent / ("AI-KOMANDA-%s.zip" % K.VERSIYA)
    propusk_papki = {".git", "__pycache__", "testy", "komandy", "diagnostika"}
    propusk_imena = {".DS_Store", "Thumbs.db", "desktop.ini"}
    skolko = 0
    with zipfile.ZipFile(arhiv, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("AI-KOMANDA/komandy/", "")
        for f in sorted(KOREN.rglob("*")):
            otn = f.relative_to(KOREN)
            if not f.is_file() or f.is_symlink() or (set(otn.parts) & propusk_papki):
                continue
            if f.name in propusk_imena or f.suffix == ".zip" or f.name.startswith("TZ-"):
                continue
            if f.suffix == ".md":
                tekst = f.read_text(encoding="utf-8")
                tekst = re.sub(r"\n*<claude-mem-context>.*?</claude-mem-context>\n*", "\n", tekst, flags=re.S)
                z.writestr("AI-KOMANDA/" + otn.as_posix(), tekst.rstrip() + "\n")
            else:
                z.write(f, "AI-KOMANDA/" + otn.as_posix())
            skolko += 1
    print("Архив мастерской готов: %s (%d файлов). Команды, тесты и черновики ТЗ в него не попали." % (arhiv, skolko))


def main():
    p = argparse.ArgumentParser(description="Мастерская AI КОМАНДА")
    sub = p.add_subparsers(dest="cmd")
    sub.add_parser("proverka")
    n = sub.add_parser("novaya")
    n.add_argument("nazvanie")
    n.add_argument("--id")
    n.add_argument("--iz-diagnostiki", action="store_true")
    n.add_argument("--kak-est", action="store_true")
    dg = sub.add_parser("diagnostika")
    dg.add_argument("chto", choices=["nachat", "reyting", "status", "perenesti", "otmenit"])
    dg.add_argument("id", nargs="?")
    dg.add_argument("--komanda")
    dg.add_argument("--kak-est", action="store_true")
    sub.add_parser("spisok")
    sub.add_parser("sync")
    sub.add_parser("vypusk")
    o = sub.add_parser("obnovit")
    o.add_argument("id")
    a = p.parse_args()
    if not a.cmd:
        p.print_help()
        sys.exit(2)
    {"proverka": cmd_proverka, "novaya": cmd_novaya, "spisok": cmd_spisok,
     "sync": cmd_sync, "obnovit": cmd_obnovit, "diagnostika": cmd_diagnostika, "vypusk": cmd_vypusk}[a.cmd](a)


if __name__ == "__main__":
    main()
