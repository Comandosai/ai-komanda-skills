#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Инструмент команды AI КОМАНДА. Только стандартная библиотека Python 3.8+.

Команды: status, sync, karta, proverit, zhurnal, upakovat.
Имена файлов и полей описаны в KONTRAKT.md мастерской.
"""
import argparse
import datetime
import hashlib
import json
import os
import re
import shutil
import sys
import time
import webbrowser
import zipfile
import uuid
import contextlib
from pathlib import Path

VERSIYA = "0.4.1"
SKRYTYE = [".claude/skills", ".agents/skills", ".agent/skills"]
PROGON = ["готово", "отказ: данные", "отказ: инструмент"]
ISHODY = ["начал"] + PROGON + ["принято", "поправил", "отклонил", "ждёт решения", "разрешил"]
PAPKI = ["agenty", "navyki", "kontekst", "obrazcy", "vhod", "dela", "vyhod", "otchety", "skripty"]
SHAGI = ["Вход", "Расспрос и процесс", "Схема команды", "Инструменты и материалы", "Навыки",
         "Первый сквозной прогон", "Калибровка", "Зачёт", "Запуск", "Приёмка и передача"]
DA = [("process", "процесс"), ("shema", "схема команды"), ("versiya", "версия команды"), ("zapusk", "запуск")]
ID_RE = re.compile(r"^[a-z0-9]+(-[a-z0-9]+)*$")
ZAGOLOVOK = ("# Журнал команды\n\n"
             "| когда | дело | шаг | кто | исход | примечание |\n"
             "|---|---|---|---|---|---|\n")
MUSOR = {".DS_Store", "Thumbs.db", "__pycache__", "desktop.ini"}

for _potok in (sys.stdout, sys.stderr):
    try:
        _potok.reconfigure(encoding="utf-8")
    except Exception:
        pass


def chitat_team(papka):
    put = papka / "team.json"
    if not put.exists():
        sys.exit("Не нашёл team.json в папке %s. Это точно папка команды?" % papka)
    try:
        team = json.loads(put.read_text(encoding="utf-8"))
        if team.get("schema") != 2:
            sys.exit("Старая схема team.json (%s). Нужна схема 2; перенеси данные по KONTRAKT.md, не меняй только номер." % team.get("schema"))
        return team
    except json.JSONDecodeError as e:
        sys.exit("team.json испорчен (строка %d): %s. Исправь файл и повтори." % (e.lineno, e.msg))


def chitat_zhurnal(papka):
    put = papka / "zhurnal.md"
    zapisi = []
    if not put.exists():
        return zapisi
    for stroka in put.read_text(encoding="utf-8").splitlines():
        s = stroka.strip()
        if not s.startswith("|") or s.startswith("|---") or s.startswith("| когда"):
            continue
        p = [x.strip() for x in s.strip("|").split("|")]
        if len(p) < 6:
            continue
        m = re.match(r"v(\d+)", p[5])
        zapisi.append({"kogda": p[0], "delo": p[1], "shag": p[2], "kto": p[3], "ishod": p[4],
                       "prim": p[5], "v": int(m.group(1)) if m else None})
    return zapisi


def povrezhdennye_stroki_zhurnala(papka):
    put = papka / "zhurnal.md"
    if not put.is_file():
        return []
    result = []
    for number, line in enumerate(put.read_text(encoding="utf-8").splitlines(), 1):
        if line.startswith("|") and not line.startswith("|---") and not line.startswith("| когда"):
            fields = [x.strip() for x in line.strip("|").split("|")]
            if len(fields) != 6 or not re.match(r"^v\d+\b", fields[5]):
                result.append(number)
    return result


def podtverzhden_progon(papka, z, tekushchiy=True):
    m = re.search(r"\brun:([a-f0-9]{32})\b", z["prim"])
    if not m or not ID_RE.match(z["delo"]):
        return False
    try:
        for put in (papka / "dela" / z["delo"]).glob("*/pasport.json"):
            d = json.loads(put.read_text(encoding="utf-8"))
            if d.get("id") != m.group(1) or d.get("versii", {}).get(z["shag"]) != z["v"]:
                continue
            e = next((x for x in d.get("etapy", []) if x.get("navyk") == z["shag"]), None)
            if not e or e.get("status") not in ("proveren", "est-problema", "ne-udalos-proverit") or z["ishod"] != e.get("ishod", "готово" if e.get("status") == "proveren" else ""):
                return False
            skill_hash = d.get("navyki_sha256", {}).get(z["shag"], "")
            if not re.fullmatch(r"[a-f0-9]{64}", skill_hash):
                return False
            if tekushchiy:
                skill = papka / "navyki" / z["shag"] / "SKILL.md"
                if not skill.is_file() or skill_hash != otpechatok_navyka(skill.parent):
                    return False
            for pole in ("rezultat", "verdikt"):
                if pole == "rezultat" and e.get("status") == "ne-udalos-proverit" and not e.get("rezultat"):
                    continue
                f = put.parent / e.get(pole, "")
                if not f.is_file() or hashlib.sha256(f.read_bytes()).hexdigest() != e.get(pole + "_sha256"):
                    return False
            return True
    except (OSError, ValueError):
        return False
    return False


def otpechatok_navyka(papka):
    h = hashlib.sha256()
    files = [papka / "SKILL.md"] + sorted((papka / "scripts").rglob("*"))
    for f in files:
        if f.is_file():
            name = f.relative_to(papka).as_posix().encode("utf-8")
            data = f.read_bytes()
            h.update(str(len(name)).encode("ascii") + b":" + name)
            h.update(str(len(data)).encode("ascii") + b":" + data)
    return h.hexdigest()


def peredannyy_navyk(papka, n):
    marker = chitat_team(papka).get("peredana", {})
    return marker.get("navyki_sha256", {}).get(n.get("id")) == otpechatok_navyka(papka / "navyki" / n.get("id", "")) and marker.get("versii", {}).get(n.get("id")) == n.get("versiya", 1)


def status_navyka(papka, navyk, zapisi):
    """Статус считает скрипт по журналу, а не модель."""
    nid = navyk.get("id", "")
    tek = navyk.get("versiya", 1)
    moi = [z for z in zapisi if z["shag"] == nid]
    progony = [z for z in moi if z["ishod"] in PROGON and podtverzhden_progon(papka, z)]
    progony = list({(z["delo"], re.search(r"run:([a-f0-9]{32})", z["prim"]).group(1)): z for z in progony}.values())
    progony_tek = [z for z in progony if z["v"] == tek]
    uspeshnye = [z for z in progony_tek if proveren_ishod(papka, z)]
    itog = {"progony": len(progony), "progony_versii": len(progony_tek),
            "gotovo_versii": len(uspeshnye),
            "versiya": tek}
    if not (papka / "navyki" / nid / "SKILL.md").exists():
        itog["status"] = "нет"
        return itog
    if peredannyy_navyk(papka, navyk) and not progony_tek:
        itog["status"] = "передан"
        return itog
    prinyato = [z for z in moi if z["ishod"] == "принято" and z["kto"] == "я"]
    if any(z["v"] == tek for z in prinyato) and progony_tek:
        itog["status"] = "принят"
    elif prinyato:
        itog["status"] = "перепроверка"
    else:
        sobytiya = [z for z in progony if z["v"] == tek]
        if not sobytiya:
            itog["status"] = "черновик"
        elif len(sobytiya) >= 3 and all(proveren_ishod(papka, z) for z in sobytiya[-3:]):
            itog["status"] = "проверен"
        else:
            itog["status"] = "калибруется"
    return itog


def proveren_ishod(papka, z):
    """Подтверждённый проверяющим отказ тоже считается успешной работой навыка."""
    m = re.search(r"\brun:([a-f0-9]{32})\b", z["prim"])
    if not m:
        return False
    for put in (papka / "dela" / z["delo"]).glob("*/pasport.json"):
        try:
            d = json.loads(put.read_text(encoding="utf-8"))
            if d.get("id") == m.group(1):
                return any(e.get("navyk") == z["shag"] and e.get("status") == "proveren"
                           for e in d.get("etapy", []))
        except (OSError, ValueError):
            continue
    return False


def hesh_papki(koren):
    h = hashlib.sha256()
    if not koren.is_dir():
        return ""
    for f in sorted(koren.rglob("*")):
        if f.is_file() and not (set(f.parts) & MUSOR):
            h.update(f.relative_to(koren).as_posix().encode("utf-8"))
            h.update(f.read_bytes())
    return h.hexdigest()


def sdelat_sync(papka, istochnik=None):
    """Копирует навыки в три скрытые папки. Возвращает (сколько навыков, список неудач)."""
    istochnik = istochnik or papka / "navyki"
    istochnik.mkdir(parents=True, exist_ok=True)
    etalon = hesh_papki(istochnik)
    neudachi = []
    for imya in SKRYTYE:
        cel = papka / imya
        if any((papka / part).is_symlink() for part in (imya.split("/")[0], imya)) or papka.resolve() not in cel.resolve().parents:
            neudachi.append("%s (ссылка ведёт за пределы команды)" % imya)
            continue
        if cel.is_dir() and not cel.is_symlink() and hesh_papki(cel) == etalon:
            continue
        try:
            if cel.is_symlink() or cel.is_file():
                cel.unlink()
            elif cel.exists():
                shutil.rmtree(cel)
            cel.parent.mkdir(parents=True, exist_ok=True)
            shutil.copytree(istochnik, cel, ignore=shutil.ignore_patterns(*MUSOR))
        except OSError as e:
            neudachi.append("%s (%s)" % (imya, e.strerror or e))
    return len([p for p in istochnik.iterdir() if p.is_dir()]), neudachi


def sostav_papok(papka):
    itog = []
    for imya in PAPKI:
        p = papka / imya
        fayly = []
        if p.is_dir():
            fayly = sorted(f.relative_to(p).as_posix() for f in p.rglob("*")
                           if f.is_file() and not (set(f.parts) & MUSOR))
        itog.append({"papka": imya, "skolko": len(fayly), "fayly": fayly[:14]})
    return itog


def put_dela(papka, delo, popytka):
    if not ID_RE.match(delo) or not ID_RE.match(popytka):
        sys.exit("Имя дела и попытки: латиница, цифры и дефис.")
    put = papka / "dela" / delo / popytka
    if papka.resolve() not in put.resolve().parents or (papka / "dela").resolve() not in put.resolve().parents:
        sys.exit("Путь дела ведёт за пределы команды.")
    return put


def chitat_pasport(papka, delo, popytka):
    put = put_dela(papka, delo, popytka) / "pasport.json"
    if not put.exists():
        sys.exit("Нет паспорта прогона %s/%s. Сначала nachat-progon." % (delo, popytka))
    return json.loads(put.read_text(encoding="utf-8"))


def zapisat_pasport(papka, delo, popytka, pasport):
    put = put_dela(papka, delo, popytka) / "pasport.json"
    tmp = put.with_name("pasport.%s.tmp" % uuid.uuid4().hex)
    tmp.write_text(json.dumps(pasport, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(str(tmp), str(put))


@contextlib.contextmanager
def blokirovat(papka, delo, popytka):
    lock = put_dela(papka, delo, popytka) / ".pasport.lock"
    for _ in range(100):
        try:
            lock.mkdir()
            break
        except FileExistsError:
            try:
                if time.time() - lock.stat().st_mtime > 60:
                    shutil.rmtree(lock)
                    continue
            except FileNotFoundError:
                continue
            time.sleep(0.05)
    else:
        sys.exit("Паспорт занят другим процессом: %s. Повтори позже." % lock)
    try:
        yield
    finally:
        lock.rmdir()


def poslednee_delo(papka):
    pasporta = list((papka / "dela").glob("*/*/pasport.json"))
    if not pasporta:
        return None
    put = max(pasporta, key=lambda p: p.stat().st_mtime_ns)
    try:
        d = json.loads(put.read_text(encoding="utf-8"))
        return {"delo": put.parent.parent.name, "popytka": put.parent.name,
                "id": d.get("id"), "etapy": d.get("etapy", []), "resheniya": d.get("resheniya", {}),
                "status": d.get("status", "")}
    except (ValueError, OSError):
        return None


def _otpechatok_vhoda(put):
    files = sorted(put.glob("00-*")) or [put / "zadanie.md"]
    h = hashlib.sha256()
    for f in files:
        if f.is_file():
            h.update(f.read_bytes())
    return h.hexdigest()


def zachetnye_dela(papka):
    result = {}
    for p in (papka / "dela").glob("z*/*/pasport.json"):
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
            if p.parent.parent.name in ("z1", "z2", "z3", "z4", "z5") and _zavershen_pasport(p, d):
                result[p.parent.parent.name] = p.parent
        except (OSError, ValueError):
            continue
    return result


def _zavershen_pasport(p, d):
    if d.get("status") != "zavershen" or not d.get("etapy"):
        return False
    for e in d["etapy"]:
        if e.get("status") != "proveren":
            return False
        for field in ("rezultat", "verdikt"):
            name = e.get(field)
            if not name or (p.parent / name).resolve().parent != p.parent.resolve():
                return False
            f = p.parent / name
            if not f.is_file() or hashlib.sha256(f.read_bytes()).hexdigest() != e.get(field + "_sha256"):
                return False
    return True


def svezhie_dela(papka):
    old = {_otpechatok_vhoda(p.parent) for p in (papka / "dela").glob("d*/*/pasport.json")}
    z = zachetnye_dela(papka)
    return {k: v for k, v in z.items() if k not in ("z1", "z2", "z3") and _otpechatok_vhoda(v) not in old}


def _bylo_pasport(p, d):
    fixed = [e for e in d.get("etapy", []) if e.get("status") in ("proveren", "est-problema", "ne-udalos-proverit")]
    if not fixed or any(e.get("status") == "idet" for e in d.get("etapy", [])):
        return False
    for e in fixed:
        for field in ("rezultat", "verdikt"):
            if field == "rezultat" and e.get("status") == "ne-udalos-proverit" and not e.get(field):
                continue
            f = p.parent / e.get(field, "")
            if f.resolve().parent != p.parent.resolve() or not f.is_file() or hashlib.sha256(f.read_bytes()).hexdigest() != e.get(field + "_sha256"):
                return False
    return True


def zachet_polon(papka):
    z = zachetnye_dela(papka)
    if set(z) != {"z1", "z2", "z3", "z4", "z5"}:
        return False
    for name in ("z1", "z2", "z3"):
        for attempt in ("p1", "p2"):
            p = papka / "dela" / name / attempt / "pasport.json"
            if not p.is_file():
                return False
            try:
                d = json.loads(p.read_text(encoding="utf-8"))
                if not (_bylo_pasport(p, d) if attempt == "p1" else _zavershen_pasport(p, d)):
                    return False
            except (OSError, ValueError):
                return False
        if _otpechatok_vhoda(papka / "dela" / name / "p1") != _otpechatok_vhoda(papka / "dela" / name / "p2"):
            return False
    return True


def blokirovki(team, papka):
    b = []
    for n in team.get("navyki", []):
        for m in n.get("materialy", []):
            if m.get("obyazatelno") and m.get("status") == "net":
                b.append("Нет материала: %s" % m.get("chto", "?"))
    for i in team.get("instrumenty", []):
        if i.get("status") == "ne-provereno":
            b.append("Не проверен инструмент: %s" % i.get("nazvanie", i.get("id", "?")))
    tochki = {k.get("id"): k for k in team.get("kontrolnye_tochki", [])}
    for put in sorted((papka / "dela").glob("*/*/pasport.json")):
        try:
            d = json.loads(put.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        if d.get("status") == "prervan":
            continue  # решение по прерванной попытке уже не нужно: дело ушло в новую попытку
        for k, v in d.get("resheniya", {}).items():
            if v.get("status") == "zhdet-resheniya":
                name = tochki.get(k, {}).get("uslovie") or k
                b.append("Ждёт решения: %s/%s, %s" % (put.parent.parent.name, put.parent.name, name))
    return b


def sobrat_dannye(papka):
    team = chitat_team(papka)
    zapisi = chitat_zhurnal(papka)
    return {
        "team": team,
        "statusy": {n.get("id", ""): status_navyka(papka, n, zapisi) for n in team.get("navyki", [])},
        "zhurnal": zapisi[-20:],
        "zapisey": len(zapisi),
        "papki": sostav_papok(papka),
        "shagi": SHAGI,
        "sobrano": datetime.datetime.now().strftime("%d.%m.%Y %H:%M"),
        "poslednee_delo": poslednee_delo(papka),
        "blokirovki": blokirovki(team, papka),
    }


def sdelat_kartu(papka, dannye=None, zapisat=True):
    shablon = papka / "skripty" / "karta.template.html"
    if not shablon.exists():
        sys.exit("Нет шаблона карты skripty/karta.template.html. Папка команды повреждена.")
    dannye = json.dumps(sobrat_dannye(papka) if dannye is None else dannye, ensure_ascii=False).replace("<", "\\u003c").replace(">", "\\u003e").replace("&", "\\u0026")
    html = shablon.read_text(encoding="utf-8").replace("/*DANNYE*/null", dannye, 1)
    if not zapisat:
        return html
    (papka / "karta.html").write_text(html, encoding="utf-8")
    return papka / "karta.html"


def proverka(papka):
    """Возвращает (ошибки, замечания)."""
    osh, zam = [], []
    team = chitat_team(papka)
    for number in povrezhdennye_stroki_zhurnala(papka):
        osh.append("Журнал: повреждена строка %d." % number)
    if team.get("peredana") and any(not peredannyy_navyk(papka, n) for n in team.get("navyki", [])):
        team.pop("peredana")
    shag = team.get("shag", 0)
    da = team.get("da", {})
    roli = {r.get("id"): r for r in team.get("roli", [])}
    navyki = {n.get("id"): n for n in team.get("navyki", [])}
    if isinstance(shag, int) and shag >= 7:
        zapisi = chitat_zhurnal(papka)
        for n in team.get("navyki", []):
            if not n.get("proveryaet") and status_navyka(papka, n, zapisi)["status"] not in ("проверен", "принят", "передан"):
                zam.append("на зачёт рано: навык %s ещё не проверен" % n.get("id", "?"))
    def vnutri(relative):
        p = Path(str(relative))
        return bool(relative) and not p.is_absolute() and ".." not in p.parts and (papka / p).resolve() != papka.resolve() and papka.resolve() in (papka / p).resolve().parents

    if not isinstance(shag, int) or not 0 <= shag <= 9:
        osh.append("team.json: shag должен быть от 0 до 9.")
    process = team.get("process", {})
    if shag >= 2 or da.get("process"):
        for pole in ("nazvanie", "vhod", "rezultat", "kriterii", "granica", "prinimaet"):
            if not process.get(pole):
                osh.append("process.%s не заполнено." % pole)
        if process.get("kriterii") and not isinstance(process["kriterii"], list):
            osh.append("process.kriterii должен быть списком.")
    if roli or da.get("shema") or shag >= 3:
        if not 2 <= len(roli) <= 3:
            osh.append("В схеме нужно 2–3 роли, кроме диспетчера.")
        for r in roli.values():
            for pole in ("poluchaet", "otdaet", "goden_esli"):
                if not r.get(pole):
                    osh.append("Роль %s: не заполнено %s." % (r.get("id"), pole))
        if not team.get("kontrolnye_tochki"):
            osh.append("Нет контрольных точек.")
        if not (papka / "kontekst" / "kontrolnye-tochki.md").exists():
            osh.append("Нет kontekst/kontrolnye-tochki.md.")
    for i in team.get("instrumenty", []):
        if not ID_RE.match(str(i.get("id", ""))):
            osh.append("Инструмент: неверный id.")
        if i.get("status") not in ("podklyuchen", "ne-provereno", "cherez-fayly", "specialist"):
            osh.append("Инструмент %s: неверный статус." % i.get("id"))
        for pole in ("id", "nazvanie", "istochnik", "deystvie", "prava", "podklyuchenie", "proba"):
            if not i.get(pole):
                osh.append("Инструмент %s: не заполнено %s." % (i.get("id"), pole))
        if i.get("status") == "podklyuchen" and not i.get("proba_proshla"):
            osh.append("Инструмент %s объявлен подключённым без успешной пробы." % i.get("id"))
    for k in team.get("kontrolnye_tochki", []):
        if not ID_RE.match(str(k.get("id", ""))):
            osh.append("Контрольная точка: неверный id.")
        if k.get("rol") not in roli:
            osh.append("Контрольная точка %s: нет роли %s." % (k.get("id"), k.get("rol")))
        for pole in ("id", "uslovie", "otvetstvennyy", "pokazat", "varianty", "srok"):
            if not k.get(pole):
                osh.append("Контрольная точка %s: не заполнено %s." % (k.get("id"), pole))
    for chto, spisok in (("роли", roli), ("навыка", navyki)):
        for i in spisok:
            if not i or not ID_RE.match(i):
                osh.append("id %s «%s»: только латиница, цифры и дефис." % (chto, i))
    for rid, r in roli.items():
        pasport = r.get("pasport") or "agenty/%s.md" % rid
        if not vnutri(pasport):
            osh.append("Паспорт роли %s: путь должен быть внутри команды." % rid)
        elif not (papka / pasport).exists():
            (osh if shag >= 3 else zam).append("Нет паспорта роли «%s»: %s." % (rid, pasport))
        for iid in r.get("instrumenty", []):
            if iid not in {i.get("id") for i in team.get("instrumenty", [])}:
                osh.append("Роль %s: инструмент %s не описан." % (rid, iid))
    if da.get("shema") and not roli:
        osh.append("Схема принята (da.shema), но ролей в team.json нет.")
    if da.get("shema") and not (papka / "agenty" / "dispetcher.md").exists():
        osh.append("Нет паспорта диспетчера agenty/dispetcher.md.")
    for s in team.get("styki", []):
        for konec in ("ot", "k"):
            if s.get(konec) not in roli:
                osh.append("Стык ссылается на несуществующую роль «%s»." % s.get(konec))
        if not s.get("polya"):
            zam.append("Стык %s → %s: не указано, какие поля передаются." % (s.get("ot"), s.get("k")))
    for nid, n in navyki.items():
        if n.get("rol") not in roli:
            osh.append("Навык «%s» привязан к несуществующей роли «%s»." % (nid, n.get("rol")))
        if n.get("proveryaet") and n["proveryaet"] not in navyki:
            osh.append("Навык «%s» проверяет несуществующий навык «%s»." % (nid, n["proveryaet"]))
        if shag >= 5 and not n.get("proveryaet") and not any(x.get("proveryaet") == nid for x in navyki.values()):
            osh.append("Для навыка %s нет парного проверяющего." % nid)
        skill = papka / "navyki" / str(nid) / "SKILL.md"
        if not skill.exists():
            (osh if shag >= 5 else zam).append("Нет файла навыка navyki/%s/SKILL.md." % nid)
        else:
            tekst = skill.read_text(encoding="utf-8")
            m = re.match(r"---\s*\n(.*?)\n---", tekst, re.S)
            if not m:
                osh.append("navyki/%s/SKILL.md: нет шапки с name и description." % nid)
            else:
                imya = re.search(r"^name:\s*(.+)$", m.group(1), re.M)
                if not imya or imya.group(1).strip().strip("\"'") != nid:
                    osh.append("navyki/%s/SKILL.md: name в шапке должен быть «%s»." % (nid, nid))
                if not re.search(r"^description:\s*\S", m.group(1), re.M):
                    osh.append("navyki/%s/SKILL.md: пустой description." % nid)
            if len(tekst.splitlines()) > 500:
                zam.append("navyki/%s/SKILL.md длиннее 500 строк, вынеси часть в references/." % nid)
        for mat in n.get("materialy", []):
            st = mat.get("status")
            if st not in ("net", "est", "pozzhe"):
                osh.append("Материал «%s» навыка «%s»: статус должен быть net, est или pozzhe." % (mat.get("chto"), nid))
            if st == "est" and (not vnutri(mat.get("gde")) or not (papka / mat["gde"]).is_file()):
                osh.append("Материал «%s» отмечен как есть, но файла %s нет." % (mat.get("chto"), mat.get("gde") or "(путь не указан)"))
            if st == "net" and mat.get("obyazatelno") and shag >= 5:
                osh.append("Нет обязательного материала «%s» для навыка «%s»." % (mat.get("chto"), nid))
            if st == "pozzhe" and mat.get("obyazatelno") and shag >= 5:
                zam.append("Материал «%s» для навыка «%s» будет позже; пробный запуск с оговоркой." % (mat.get("chto"), nid))
    for papki_dir in (papka / "navyki",):
        for p in papki_dir.iterdir() if papki_dir.is_dir() else []:
            if p.is_dir() and p.name not in navyki:
                zam.append("Папка navyki/%s есть, а в team.json такого навыка нет." % p.name)
    if team.get("priemka", {}).get("status") not in ("ne-provedena", "proshla"):
        osh.append("priemka.status: ожидается ne-provedena или proshla.")
    if team.get("priemka", {}).get("status") == "proshla":
        for pole in ("kogda", "delo", "usloviya"):
            if not team["priemka"].get(pole):
                osh.append("Приёмка пройдена, но priemka.%s пусто." % pole)
        if not da.get("zapusk"):
            osh.append("Приёмка отмечена до подтверждения запуска.")
    if da.get("versiya"):
        if not (papka / "otchety" / "zachet-bylo-stalo.md").exists():
            osh.append("Версия принята без отчёта otchety/zachet-bylo-stalo.md.")
        if not team.get("peredana"):
            if not zachet_polon(papka):
                osh.append("Версия принята без завершённых z1-z5 и серий p1/p2 для z1-z3.")
            if len(svezhie_dela(papka)) < 2:
                osh.append("Версия принята без двух свежих дел, не повторяющих d*.")
            elif len({_otpechatok_vhoda(v) for v in svezhie_dela(papka).values()}) < 2:
                osh.append("Два свежих дела повторяют друг друга.")
        for n in navyki.values() if not team.get("peredana") else []:
            if not n.get("proveryaet") and status_navyka(papka, n, chitat_zhurnal(papka))["status"] != "принят":
                osh.append("Навык %s текущей версии не принят человеком." % n.get("id"))
    if da.get("zapusk"):
        if team.get("zapusk", {}).get("sposob") != "vruchnuyu":
            osh.append("Запуск подтверждён без способа запуска.")
        est_reshenie = False
        for p in (papka / "dela").glob("*/*/pasport.json"):
            try:
                d = json.loads(p.read_text(encoding="utf-8"))
                est_reshenie |= any(r.get("status") == "razresheno" for r in d.get("resheniya", {}).values())
            except (ValueError, OSError):
                continue
        if not est_reshenie and not team.get("peredana", {}).get("tochka_proverena"):
            osh.append("Запуск подтверждён без пробы контрольной точки.")
    etalon = hesh_papki(papka / "navyki")
    for imya in SKRYTYE:
        if hesh_papki(papka / imya) != etalon:
            osh.append("Копия навыков %s отличается от navyki/. Выполни команду sync." % imya)
    for z in chitat_zhurnal(papka):
        if z["ishod"] not in ISHODY:
            osh.append("Журнал: неизвестный исход «%s» (%s)." % (z["ishod"], z["kogda"]))
        if z["shag"] != "komanda" and z["shag"] not in navyki:
            zam.append("Журнал: запись про неизвестный навык «%s» (%s)." % (z["shag"], z["kogda"]))
        if z["ishod"] in PROGON and not team.get("peredana") and not podtverzhden_progon(papka, z, tekushchiy=False):
            zam.append("Журнал: прогон %s/%s не подтверждён паспортом и файлами." % (z["delo"], z["shag"]))
    for p in (papka / "dela").glob("*/*/pasport.json"):
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
            for e in d.get("etapy", []):
                if e.get("status") in ("proveren", "est-problema"):
                    for pole in ("rezultat", "verdikt"):
                        f = p.parent / e.get(pole, "")
                        if not f.is_file():
                            osh.append("Прогон %s: этап %s без файла %s." % (p.parent, e.get("navyk"), pole))
                        elif e.get(pole + "_sha256") != hashlib.sha256(f.read_bytes()).hexdigest():
                            osh.append("Прогон %s: файл %s изменён после фиксации этапа." % (p.parent, pole))
        except (ValueError, OSError):
            osh.append("Повреждён паспорт прогона %s." % p)
    for f in list(papka.glob("*.md")) + list((papka / "agenty").glob("*.md")) + list((papka / "navyki").rglob("*.md")):
        t = f.read_text(encoding="utf-8", errors="ignore")
        if "_masterskaya" in t or re.search(r"(/Users/|/home/|[A-Z]:\\Users)", t):
            osh.append("%s ссылается на путь вне папки команды. Команду нельзя будет передать." % f.relative_to(papka).as_posix())
    return osh, zam


# ---------- команды ----------

def cmd_status(papka, a):
    d = sobrat_dannye(papka)
    t = d["team"]
    shag = t.get("shag", 0)
    print("Команда: %s (%s)" % (t.get("komanda", {}).get("nazvanie"), t.get("komanda", {}).get("id")))
    print("Шаг %d из 9: %s" % (shag, SHAGI[shag] if 0 <= shag < len(SHAGI) else "?"))
    print("Ждём от вас: %s" % (t.get("zhdem_ot_vas") or "сейчас ничего"))
    print("Блокировки: %s" % ("; ".join(d["blokirovki"]) or "нет"))
    print("Дальше: %s" % (t.get("sleduyushchee") or "не записано"))
    print("Подтверждения: " + ", ".join(
        "%s %s" % (nazv, "ДА (%s)" % t["da"][k]["kogda"] if t.get("da", {}).get(k) else "нет") for k, nazv in DA))
    print("Роли: %d, навыки: %d, стыки: %d, записей в журнале: %d" % (
        len(t.get("roli", [])), len(t.get("navyki", [])), len(t.get("styki", [])), d["zapisey"]))
    for n in t.get("navyki", []):
        if n.get("proveryaet"):
            continue
        s = d["statusy"][n.get("id", "")]
        net = [m.get("chto") for m in n.get("materialy", []) if m.get("status") != "est" and m.get("obyazatelno")]
        print("  - %s [%s] v%d: %s, прогонов этой версии %d (готово %d)%s" % (
            n.get("id"), n.get("rol"), s["versiya"], s["status"], s["progony_versii"], s["gotovo_versii"],
            "; НЕ ХВАТАЕТ: " + ", ".join(net) if net else ""))
        checks = [x.get("nazvanie", x.get("id")) for x in t.get("navyki", []) if x.get("proveryaet") == n.get("id")]
        if checks:
            print("    Проверяет: %s" % ", ".join(checks))
    if isinstance(shag, int) and shag >= 7:
        for n in t.get("navyki", []):
            if not n.get("proveryaet") and d["statusy"][n.get("id", "")]["status"] not in ("проверен", "принят", "передан"):
                print("на зачёт рано: навык %s ещё не проверен" % n.get("id", "?"))
    for i in t.get("instrumenty", []):
        print("Инструмент %s: %s" % (i.get("nazvanie", i.get("id")), i.get("status")))
    ld = d["poslednee_delo"]
    if ld:
        print("Последнее дело: %s/%s, %s" % (ld["delo"], ld["popytka"], ld["status"]))
        for e in ld["etapy"]:
            print("  %s: %s" % (e.get("navyk"), e.get("status")))
    osh, zam = proverka(papka)
    print("Проверка: ошибок %d, замечаний %d%s" % (len(osh), len(zam), " (подробно: proverit)" if osh or zam else ""))


def cmd_sync(papka, a):
    n, neud = sdelat_sync(papka)
    if neud:
        print("НЕ УДАЛОСЬ записать: %s." % "; ".join(neud))
        sys.exit("Приложение не даёт писать в служебную папку. Разреши запись (полный доступ к папке) и повтори sync.")
    print("Готово: %d навык(ов) из navyki/ скопированы в %s." % (n, ", ".join(SKRYTYE)))


def cmd_karta(papka, a):
    put = sdelat_kartu(papka)
    print("Карта собрана: %s" % put)
    if a.open:
        webbrowser.open(put.resolve().as_uri())


def cmd_proverit(papka, a):
    osh, zam = proverka(papka)
    for x in osh:
        print("ОШИБКА: " + x)
    for x in zam:
        print("ЗАМЕЧАНИЕ: " + x)
    print("Итог: ошибок %d, замечаний %d." % (len(osh), len(zam)))
    if osh:
        sys.exit(1)


def cmd_zhurnal(papka, a):
    team = chitat_team(papka)
    navyki = {n.get("id"): n for n in team.get("navyki", [])}
    if a.ishod not in ISHODY:
        sys.exit("Исход должен быть одним из: %s." % "; ".join(ISHODY))
    if a.ishod in PROGON:
        sys.exit("Исходы пробного запуска пишет только fiksirovat-etap.")
    if a.ishod == "принято":
        sys.exit("Принятие навыка записывает отдельная команда prinyat-navyk.")
    if a.shag != "komanda" and a.shag not in navyki:
        sys.exit("Навыка «%s» нет в team.json. Есть: %s, либо komanda." % (a.shag, ", ".join(navyki) or "пока ни одного"))
    roli = [r.get("id") for r in team.get("roli", [])] + ["я", "dispetcher", "mehanik", "provodnik"]
    if a.kto not in roli:
        sys.exit("Кто «%s» не найден. Допустимо: %s." % (a.kto, ", ".join(roli)))
    versiya = navyki[a.shag].get("versiya", 1) if a.shag in navyki else 1
    zapisat_sobytie(papka, a.delo, a.shag, a.kto, a.ishod, a.prim or "", versiya)
    sdelat_kartu(papka)
    if a.shag in navyki:
        s = status_navyka(papka, navyki[a.shag], chitat_zhurnal(papka))
        print("Записано. Навык %s v%d: %s, прогонов этой версии %d." % (a.shag, versiya, s["status"], s["progony_versii"]))
    else:
        print("Записано.")


def cmd_prinyat_navyk(papka, a):
    team = chitat_team(papka)
    n = next((x for x in team.get("navyki", []) if x.get("id") == a.navyk), None)
    if n and n.get("proveryaet"):
        sys.exit("Проверяющий принимается вместе со своим навыком %s." % n["proveryaet"])
    decision = team.get("da", {}).get("versiya")
    if not n or not decision or not decision.get("chto") or a.reshenie != decision["chto"]:
        sys.exit("Сначала запиши явное подтверждение версии в da.versiya; текст решения должен совпадать.")
    if not any(z["shag"] == a.navyk and z["v"] == n.get("versiya", 1) and z["ishod"] in PROGON and podtverzhden_progon(papka, z)
               for z in chitat_zhurnal(papka)):
        sys.exit("Навык текущей версии ещё не прошёл подтверждённый пробный запуск.")
    if any(z["shag"] == a.navyk and z["v"] == n.get("versiya", 1) and z["ishod"] == "принято" for z in chitat_zhurnal(papka)):
        sys.exit("Навык этой версии уже принят.")
    zapisat_sobytie(papka, "zachet", a.navyk, "я", "принято", decision["chto"], n.get("versiya", 1))
    sdelat_kartu(papka)
    print("Принятие навыка записано.")


def cmd_nachat_progon(papka, a):
    team = chitat_team(papka)
    put = put_dela(papka, a.delo, a.popytka)
    if put.exists():
        sys.exit("Попытка уже существует. Продолжи её или выбери новую попытку.")
    navyki = {n["id"]: n for n in team.get("navyki", [])}
    etapy = a.etapy.split(",")
    if not etapy or any(x not in navyki for x in etapy):
        sys.exit("Все этапы должны быть id навыков из team.json.")
    for x in etapy:
        for m in navyki[x].get("materialy", []):
            if m.get("obyazatelno") and m.get("status") == "net":
                sys.exit("Нет обязательного материала «%s» для навыка %s." % (m.get("chto"), x))
            if m.get("status") == "est":
                f = papka / str(m.get("gde", ""))
                if not f.is_file() or papka.resolve() not in f.resolve().parents:
                    sys.exit("Материал «%s» отмечен как имеющийся, но файла внутри команды нет." % m.get("chto"))
            if m.get("obyazatelno") and m.get("status") == "pozzhe":
                print("ОГОВОРКА: материал «%s» будет позже; результат пробного запуска ограничен." % m.get("chto"))
    for old in (papka / "dela" / a.delo).glob("*/pasport.json"):
        try:
            d = json.loads(old.read_text(encoding="utf-8"))
            if d.get("status") in ("idet", "zhdet-resheniya", "ostanovlen"):
                d["status"] = "prervan"
                zapisat_pasport(papka, a.delo, old.parent.name, d)
        except (OSError, ValueError):
            pass
    put.mkdir(parents=True)
    (put / "zadanie.md").write_text(a.zadanie + "\n\nКритерии: " + a.kriterii + "\n", encoding="utf-8")
    pasport = {"id": uuid.uuid4().hex, "nachalo_ns": time.time_ns(),
               "nachalo": datetime.datetime.now().isoformat(timespec="seconds"),
               "versii": {x: navyki[x]["versiya"] for x in etapy},
               "navyki_sha256": {x: otpechatok_navyka(papka / "navyki" / x) for x in etapy},
               "status": "idet", "etapy": [{"navyk": x, "status": "zhdet", "popytki": 0} for x in etapy],
               "resheniya": {}}
    zapisat_pasport(papka, a.delo, a.popytka, pasport)
    (put / "razbor.md").write_text("# Разбор\n\nПока нет.\n", encoding="utf-8")
    (put / "itog.md").write_text("# Итог\n\nПока нет.\n", encoding="utf-8")
    sdelat_kartu(papka)
    print("Прогон начат: %s/%s, id %s" % (a.delo, a.popytka, pasport["id"]))


def cmd_nachat_etap(papka, a):
    d = chitat_pasport(papka, a.delo, a.popytka)
    e = next((x for x in d["etapy"] if x["navyk"] == a.navyk), None)
    if not e:
        sys.exit("Такого этапа в прогоне нет.")
    if e["status"] not in ("zhdet", "idet") or d.get("status") == "prervan":
        sys.exit("Этап уже завершён или попытка прервана.")
    if e["popytki"] >= 3:
        sys.exit("Этап уже запускали 3 раза. Нужен разбор и новая попытка дела.")
    e["popytki"] += 1
    e["status"] = "idet"
    e["nachalo_ns"] = time.time_ns()
    put = put_dela(papka, a.delo, a.popytka)
    e["fayly_do"] = {f.name: hashlib.sha256(f.read_bytes()).hexdigest() for f in put.iterdir() if f.is_file()}
    zapisat_pasport(papka, a.delo, a.popytka, d)
    sdelat_kartu(papka)
    number = d["etapy"].index(e) + 1
    for tip in ("rezultat", "verdikt"):
        print("%s: %s/%02d-%s.md" % (tip, put.relative_to(papka).as_posix(), number, tip))
    print("Этап начат. Лимит: 1 запуск и 2 повтора; осталось %d." % (3 - e["popytki"]))


def _fayl_etapa(papka, delo, popytka, imya, nachalo, fayly_do=None):
    put = put_dela(papka, delo, popytka)
    f = (put / imya).resolve()
    if not f.is_file() and Path(imya).name == imya and (papka / imya).is_file():
        sys.exit("Файл %s найден в корне команды. Перенеси его в %s." % (imya, (put / imya).relative_to(papka).as_posix()))
    if f.parent != put.resolve() or not f.is_file() or f.stat().st_mtime_ns <= nachalo:
        sys.exit("Нет свежего файла %s, созданного после начала этапа." % imya)
    if (fayly_do or {}).get(f.name) == hashlib.sha256(f.read_bytes()).hexdigest():
        sys.exit("Файл %s не изменился после начала этапа." % imya)
    return f


def cmd_fiksirovat_etap(papka, a):
    d = chitat_pasport(papka, a.delo, a.popytka)
    e = next((x for x in d["etapy"] if x["navyk"] == a.navyk), None)
    if e and e.get("status") in ("proveren", "est-problema", "ne-udalos-proverit"):
        marker = "run:" + d["id"]
        if not any(z["delo"] == a.delo and z["shag"] == a.navyk and marker in z["prim"] for z in chitat_zhurnal(papka)):
            rol = next((n.get("rol") for n in chitat_team(papka).get("navyki", []) if n.get("id") == a.navyk), "dispetcher")
            zapisat_sobytie(papka, a.delo, a.navyk, rol, e.get("ishod", "готово" if e["status"] == "proveren" else "отказ: данные"), a.popytka + " " + marker, d["versii"].get(a.navyk, 1))
            print("Недостающая запись журнала восстановлена.")
            return
        sys.exit("Этап уже зафиксирован. Повторный прогон нужен в новой попытке.")
    if not e or e["status"] != "idet":
        sys.exit("Сначала начни этот этап командой nachat-etap.")
    if a.status not in ("proveren", "est-problema", "ne-udalos-proverit"):
        sys.exit("Статус: proveren, est-problema или ne-udalos-proverit.")
    rezultat = None if a.status == "ne-udalos-proverit" and not a.rezultat else _fayl_etapa(papka, a.delo, a.popytka, a.rezultat, e["nachalo_ns"], e.get("fayly_do"))
    verdikt = _fayl_etapa(papka, a.delo, a.popytka, a.verdikt, e["nachalo_ns"], e.get("fayly_do"))
    if rezultat == verdikt:
        sys.exit("Результат и вердикт должны быть отдельными файлами.")
    tekst_verdikta = verdikt.read_text(encoding="utf-8", errors="replace").splitlines()[0].strip().upper()
    marker = {"proveren": "ГОТОВО", "est-problema": "НЕ ГОТОВО",
              "ne-udalos-proverit": "НЕ УДАЛОСЬ ПРОВЕРИТЬ"}[a.status]
    if marker != tekst_verdikta:
        sys.exit("Вердикт в файле не подтверждает указанный статус этапа: %s." % marker)
    if rezultat:
        digest = hashlib.sha256(rezultat.read_bytes()).hexdigest()
        for old in (papka / "dela" / a.delo).glob("*/pasport.json"):
            if old.parent.name == a.popytka:
                continue
            try:
                previous = json.loads(old.read_text(encoding="utf-8"))
                if any(x.get("navyk") == a.navyk and x.get("status") == "est-problema" and x.get("rezultat_sha256") == digest for x in previous.get("etapy", [])):
                    sys.exit("Результат совпадает с прошлой попыткой этого дела; нужен новый результат.")
            except (OSError, ValueError):
                continue
    if a.ishod and a.ishod not in ("отказ: данные", "отказ: инструмент"):
        sys.exit("Причина: отказ: данные или отказ: инструмент.")
    if a.status != "proveren" and not a.ishod:
        sys.exit("Для неудачи укажи --ishod.")
    e.update({"status": a.status, "rezultat": rezultat.name if rezultat else "", "verdikt": verdikt.name,
              "ishod": a.ishod or "готово",
              "rezultat_sha256": hashlib.sha256(rezultat.read_bytes()).hexdigest() if rezultat else "",
              "verdikt_sha256": hashlib.sha256(verdikt.read_bytes()).hexdigest(),
              "zaversheno": datetime.datetime.now().isoformat(timespec="seconds")})
    if all(x["status"] not in ("zhdet", "idet") for x in d["etapy"]):
        d["status"] = "zavershen"
    zapisat_pasport(papka, a.delo, a.popytka, d)
    rol = next((n.get("rol") for n in chitat_team(papka).get("navyki", []) if n.get("id") == a.navyk), "dispetcher")
    zapisat_sobytie(papka, a.delo, a.navyk, rol,
                    e["ishod"], a.popytka + " run:" + d["id"],
                    d["versii"].get(a.navyk, 1))
    sdelat_kartu(papka)
    print("Этап зафиксирован: %s. Файлы проверены." % a.status)


def _kontrolnaya(team, id_):
    k = next((x for x in team.get("kontrolnye_tochki", []) if x.get("id") == id_), None)
    if not k:
        sys.exit("Контрольная точка %s не описана в team.json." % id_)
    return k


def _hash_rezultata(papka, delo, popytka, imya):
    put = put_dela(papka, delo, popytka)
    f = (put / imya).resolve()
    if f.parent != put.resolve() or not f.is_file():
        sys.exit("Нет файла результата в папке этого дела.")
    return hashlib.sha256(f.read_bytes()).hexdigest()


def cmd_zapros_resheniya(papka, a):
    team = chitat_team(papka)
    _kontrolnaya(team, a.tochka)
    d = chitat_pasport(papka, a.delo, a.popytka)
    digest = _hash_rezultata(papka, a.delo, a.popytka, a.rezultat)
    old = d["resheniya"].get(a.tochka)
    if old and old.get("status") == "razresheno" and old.get("sha256") == digest:
        sys.exit("Для этой версии уже есть решение. Повторный запрос не нужен.")
    event = uuid.uuid4().hex
    d["resheniya"][a.tochka] = {"status": "zhdet-resheniya", "rezultat": a.rezultat, "sobytie_id": event,
                                "sha256": digest, "kogda": datetime.datetime.now().isoformat(timespec="seconds")}
    d["status"] = "zhdet-resheniya"
    zapisat_pasport(papka, a.delo, a.popytka, d)
    zapisat_sobytie(papka, a.delo, "komanda", "dispetcher", "ждёт решения", a.tochka + " event:" + event)
    sdelat_kartu(papka)
    print("Ждёт решения человека по %s. До ответа действие запрещено." % a.tochka)


def cmd_reshenie(papka, a):
    d = chitat_pasport(papka, a.delo, a.popytka)
    r = d["resheniya"].get(a.tochka)
    if r and r.get("status") == a.otvet and r.get("sobytie_id"):
        event = "event:" + r["sobytie_id"]
        ishod = "разрешил" if a.otvet == "razresheno" else "отклонил"
        if not any(z["delo"] == a.delo and z["ishod"] == ishod and event in z["prim"] for z in chitat_zhurnal(papka)):
            zapisat_sobytie(papka, a.delo, "komanda", "я", ishod, a.tochka + " " + event)
            print("Недостающая запись решения восстановлена.")
            return
    if not r or r["status"] != "zhdet-resheniya":
        sys.exit("Нет ожидающего запроса решения по этой точке.")
    if a.otvet not in ("razresheno", "otkloneno"):
        sys.exit("Ответ: razresheno или otkloneno.")
    if _hash_rezultata(papka, a.delo, a.popytka, r["rezultat"]) != r["sha256"]:
        sys.exit("Результат изменился после запроса. Запроси решение для новой версии.")
    r.update({"status": a.otvet, "reshil": "я", "resheno": datetime.datetime.now().isoformat(timespec="seconds"),
              "sobytie_id": r.get("sobytie_id") or uuid.uuid4().hex})
    d["status"] = ("idet" if any(e.get("status") in ("zhdet", "idet") for e in d["etapy"]) else "zavershen") if a.otvet == "razresheno" else "ostanovlen"
    zapisat_pasport(papka, a.delo, a.popytka, d)
    zapisat_sobytie(papka, a.delo, "komanda", "я", "разрешил" if a.otvet == "razresheno" else "отклонил", a.tochka + " event:" + r["sobytie_id"])
    sdelat_kartu(papka)
    print("Решение записано: %s." % a.otvet)


def cmd_razresheno(papka, a):
    with blokirovat(papka, a.delo, a.popytka):
        d = chitat_pasport(papka, a.delo, a.popytka)
        r = d["resheniya"].get(a.tochka)
        if not r or r["status"] != "razresheno" or r["rezultat"] != a.rezultat or _hash_rezultata(papka, a.delo, a.popytka, a.rezultat) != r["sha256"]:
            sys.exit("ОТКАЗ: нет разрешения человека на эту версию результата.")
        if r.get("deystvie_nachato"):
            sys.exit("ОТКАЗ: действие уже начинали. Повтор запрещён; разберите состояние вручную.")
        r["deystvie_nachato"] = datetime.datetime.now().isoformat(timespec="seconds")
        zapisat_pasport(papka, a.delo, a.popytka, d)
    sdelat_kartu(papka)
    print("Разрешено для этой версии результата. Попытка действия отмечена, повтор запрещён.")


def zapisat_sobytie(papka, delo, shag, kto, ishod, prim, versiya=1):
    s = lambda x: str(x).replace("|", "/").replace("\n", " ").strip()
    data = ("| %s | %s | %s | %s | %s | v%d %s |\n" %
            (datetime.datetime.now().strftime("%Y-%m-%d %H:%M"), s(delo), s(shag), s(kto), s(ishod), versiya, s(prim))).encode("utf-8")
    lock = papka / ".zhurnal.lock"
    for _ in range(100):
        try:
            lock.mkdir()
            break
        except FileExistsError:
            try:
                if time.time() - lock.stat().st_mtime > 60:
                    shutil.rmtree(lock)
                    continue
            except FileNotFoundError:
                continue
            time.sleep(0.05)
    else:
        sys.exit("Журнал занят другим процессом: %s. Повтори позже." % lock)
    try:
        put = papka / "zhurnal.md"
        if not put.exists():
            put.write_text(ZAGOLOVOK, encoding="utf-8")
        fd = os.open(str(put), os.O_WRONLY | os.O_APPEND)
        try:
            if os.write(fd, data) != len(data):
                raise OSError("Не удалось записать журнал полностью")
        finally:
            os.close(fd)
    finally:
        lock.rmdir()


def cmd_upakovat(papka, a):
    osh, zam = proverka(papka)
    if osh and not a.vse_ravno:
        for x in osh:
            print("ОШИБКА: " + x)
        sys.exit("Упаковка остановлена: сначала исправь ошибки (или добавь --vse-ravno).")
    _, neud = sdelat_sync(papka)
    if neud:
        sys.exit("Не удалось обновить копии навыков: %s. Разреши запись в папку и повтори." % "; ".join(neud))
    team = chitat_team(papka)
    if team.get("da", {}).get("versiya") and not team.get("peredana"):
        team["peredana"] = {"kogda": datetime.date.today().isoformat(),
                           "del_v_zachete": len(zachetnye_dela(papka)),
                           "tochka_proverena": any(
                               any(r.get("status") == "razresheno" for r in json.loads(p.read_text(encoding="utf-8")).get("resheniya", {}).values())
                               for p in (papka / "dela").glob("*/*/pasport.json"))}
    kid = team.get("komanda", {}).get("id")
    if not isinstance(kid, str) or not ID_RE.fullmatch(kid):
        sys.exit("Неверный komanda.id: только латиница, цифры и дефис.")
    arhiv = papka.parent / ("%s-%s.zip" % (kid, datetime.date.today().isoformat()))
    if arhiv.resolve().parent != papka.parent.resolve():
        sys.exit("Архив должен лежать рядом с папкой команды.")
    if team.get("peredana"):
        team["peredana"]["navyki_sha256"] = {n["id"]: otpechatok_navyka(papka / "navyki" / n["id"]) for n in team.get("navyki", [])}
        team["peredana"]["versii"] = {n["id"]: n.get("versiya", 1) for n in team.get("navyki", [])}
    dannye = sobrat_dannye(papka)
    dannye["team"] = team
    if a.bez_zhurnala:
        dannye.update(zhurnal=[], zapisey=0, poslednee_delo=None)
        dannye["blokirovki"] = [x for x in dannye["blokirovki"] if not x.startswith("Ждёт решения:")]
        for folder in dannye["papki"]:
            if folder["papka"] in ("dela", "vhod", "vyhod"):
                folder.update(skolko=0, fayly=[])
    karta = sdelat_kartu(papka, dannye, zapisat=False)
    lichnoe = set() if a.s_delami else {"dela", "vhod", "vyhod"}
    skolko = 0
    tmp = arhiv.with_name("." + arhiv.name + "." + uuid.uuid4().hex + ".tmp")
    try:
        with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
            for imya in PAPKI:
                z.writestr("%s/%s/" % (kid, imya), "")
            for f in sorted(papka.rglob("*")):
                otn = f.relative_to(papka)
                if f.is_symlink() or not f.is_file() or (set(otn.parts) & MUSOR) or f.suffix == ".zip":
                    continue
                if otn.parts[0] in lichnoe or otn.parts[0] in (".git",):
                    continue
                if a.bez_zhurnala and otn.as_posix() == "zhurnal.md":
                    z.writestr("%s/zhurnal.md" % kid, ZAGOLOVOK)
                elif otn.as_posix() == "karta.html":
                    z.writestr("%s/karta.html" % kid, karta)
                elif otn.as_posix() == "team.json":
                    z.writestr("%s/team.json" % kid, json.dumps(team, ensure_ascii=False, indent=2) + "\n")
                else:
                    z.write(f, "%s/%s" % (kid, otn.as_posix()))
                skolko += 1
        os.replace(str(tmp), str(arhiv))
    finally:
        if tmp.exists():
            tmp.unlink()
    print("Архив готов: %s (%d файлов)." % (arhiv, skolko))
    if lichnoe:
        print("Дела, входящие и готовые результаты в архив НЕ попали (там могут быть данные клиентов).")
    print("Образцы и знания в архиве ЕСТЬ%s. Проверь, что в них нет личных данных." % (
        ", журнал пустой" if a.bez_zhurnala else ", журнал тоже"))


def main():
    p = argparse.ArgumentParser(description="Инструмент команды AI КОМАНДА")
    p.add_argument("--papka", help="папка команды (по умолчанию та, где лежит этот скрипт)")
    sub = p.add_subparsers(dest="cmd")
    sub.add_parser("status")
    sub.add_parser("sync")
    k = sub.add_parser("karta")
    k.add_argument("--open", action="store_true")
    sub.add_parser("proverit")
    zh = sub.add_parser("zhurnal")
    zh.add_argument("--delo", required=True)
    zh.add_argument("--shag", required=True)
    zh.add_argument("--kto", required=True)
    zh.add_argument("--ishod", required=True)
    zh.add_argument("--prim", default="")
    pn = sub.add_parser("prinyat-navyk")
    pn.add_argument("--navyk", required=True)
    pn.add_argument("--reshenie", required=True)
    n = sub.add_parser("nachat-progon")
    for key in ("delo", "popytka", "zadanie", "kriterii", "etapy"):
        n.add_argument("--" + key, required=True)
    n = sub.add_parser("nachat-etap")
    for key in ("delo", "popytka", "navyk"):
        n.add_argument("--" + key, required=True)
    n = sub.add_parser("fiksirovat-etap")
    for key in ("delo", "popytka", "navyk", "verdikt", "status"):
        n.add_argument("--" + key, required=True)
    n.add_argument("--rezultat", default="")
    n.add_argument("--ishod", default="")
    n = sub.add_parser("zapros-resheniya")
    for key in ("delo", "popytka", "tochka", "rezultat"):
        n.add_argument("--" + key, required=True)
    n = sub.add_parser("reshenie")
    for key in ("delo", "popytka", "tochka", "otvet"):
        n.add_argument("--" + key, required=True)
    n = sub.add_parser("razresheno")
    for key in ("delo", "popytka", "tochka", "rezultat"):
        n.add_argument("--" + key, required=True)
    u = sub.add_parser("upakovat")
    u.add_argument("--s-delami", dest="s_delami", action="store_true")
    u.add_argument("--bez-zhurnala", dest="bez_zhurnala", action="store_true")
    u.add_argument("--vse-ravno", dest="vse_ravno", action="store_true")
    a = p.parse_args()
    if not a.cmd:
        p.print_help()
        sys.exit(2)
    papka = Path(a.papka).resolve() if a.papka else Path(__file__).resolve().parent.parent
    {"status": cmd_status, "sync": cmd_sync, "karta": cmd_karta, "proverit": cmd_proverit,
     "prinyat-navyk": cmd_prinyat_navyk,
     "zhurnal": cmd_zhurnal, "upakovat": cmd_upakovat, "nachat-progon": cmd_nachat_progon,
     "nachat-etap": cmd_nachat_etap, "fiksirovat-etap": cmd_fiksirovat_etap,
     "zapros-resheniya": cmd_zapros_resheniya, "reshenie": cmd_reshenie,
     "razresheno": cmd_razresheno}[a.cmd](papka, a)


if __name__ == "__main__":
    main()
